def findGradeOf(number_of_subjects,sub_grade_points,list_of_credits):  
    grade_into_credits=[]
    for i,j in zip(sub_grade_points,list_of_credits):
        grade_into_credits.append(i*float(j))
    
    total_credits=sum(list_of_credits)
    return(sum(grade_into_credits)/total_credits)