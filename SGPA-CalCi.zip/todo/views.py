from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect, HttpResponse
from .models import TodoItem
from calculate import findGradeOf

first_time = True

# Create your views here.
def todoView(request):
  if request.method == "POST":
    d=dict(request.POST)
    print(d)
    d['grades']=list(map(int,d['grades']))
    d['credits']=list(map(int,d['credits']))
    res=findGradeOf(int(d['nos'][0]),d['grades'],d['credits'])
    print(res)
    context={'res':res,'bar':res*10}
    return render(request,"result.html",context)
  return render(request, 'home.html')